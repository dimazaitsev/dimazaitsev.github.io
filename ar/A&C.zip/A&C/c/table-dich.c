#include <stdio.h>
#include <stdlib.h>

#define N 16

struct person {
    char surname[N+1];
    char name[N+1];
    int weight;
    int height;
};

main(int argc, char *argv[])
{
  int n,i,i1,found,c,left,right;
  struct person * sp;
  
  scanf("%d",&n);
  
  sp=malloc(n*sizeof(struct person));
  
  // input table
  for(i=0;i<n;i++)
  {
    scanf("%s %s %d %d",sp[i].surname,sp[i].name,&(sp[i].weight),&(sp[i].height));
  }
  
  // output table
  for(i=0;i<n;i++)
  {
    printf("%-16s %-16s %3d %3d\n",sp[i].surname,sp[i].name,sp[i].weight,sp[i].height);
  }
  
  // dichotomia table search
  found=0;
  left=0;
  right=n-1;
  while(left<right-1)
  {
    i=(left+right)/2;
    // printf("%d %d %d\n", left,right, i);
    c=strcmp(argv[1],sp[i].surname);
    if(c==0){found=1;break;}
    else if(c<0)
      right=i;
    else
      left=i;
  }
  if(!found)
    for(i=left;i<=right;i++)
       if(strcmp(argv[1],sp[i].surname)==0){found=1;break;}

  if(found)printf("\n\n%-16s %-16s %3d %3d\n",sp[i].surname,sp[i].name,sp[i].weight,sp[i].height);
  else printf("\n\nnothing\n");
}
