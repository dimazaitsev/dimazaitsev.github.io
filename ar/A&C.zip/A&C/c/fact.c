#include <stdio.h>
#include <stdlib.h>

int fact( int n ) 
{ 
  int f;
  
  printf("call fact( %d )\n", n);
  if(n==0) f=1; 
      else f=n*fact( n-1 );
  printf("return fact( %d ) = %d \n", n, f);
  
  return( f ); 
}

main(int argc, char * argv[])
{
  int n=atoi(argv[1]);
  int f=fact(n);
  printf("factorial( %d ) = %d\n", n, f);
}




