#include <stdio.h>

int gcd( int a,int b ) 
{ 
  while( a != b ) 
    if( a > b ) 
	a = a - b; 
    else 
	b = b - a; 
  return( a ); 
}

main(int argc, char * argv[])
{
  int x=atoi(argv[1]);
  int y=atoi(argv[2]);
  printf("%d", gcd(x,y));
}
