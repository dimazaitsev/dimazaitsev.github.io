#include <stdio.h>
#include <stdlib.h>

void disc_move( int n, char a, char b, char c ) 
{ 
  if(n>1)disc_move( n-1, a, c, b );
  printf("move disc from %c to %c\n", a, c );
  if(n>1)disc_move( n-1, b, a, c );
}

main(int argc, char * argv[])
{
  disc_move( atoi(argv[1]), 'A', 'B', 'C' );
}




