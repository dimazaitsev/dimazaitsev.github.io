#include <stdio.h>
#include <stdlib.h>

#define N 16

struct person {
    char surname[N+1];
    char name[N+1];
    int weight;
    int height;
};

main(int argc, char *argv[])
{
  int n,i,i1,found;
  struct person * sp;
  
  scanf("%d",&n);
  
  sp=malloc(n*sizeof(struct person));
  
  // input table
  for(i=0;i<n;i++)
  {
    scanf("%s %s %d %d",sp[i].surname,sp[i].name,&(sp[i].weight),&(sp[i].height));
  }
  
  // output table
  for(i=0;i<n;i++)
  {
    printf("%-16s %-16s %3d %3d\n",sp[i].surname,sp[i].name,sp[i].weight,sp[i].height);
  }
  
  // table search
  found=0;
  for(i=0;i<n;i++)
  {
    if(strcmp(argv[1],sp[i].surname)==0){found=1;i1=i;break;}
  }

  if(found)printf("\n\n%-16s %-16s %3d %3d\n",sp[i1].surname,sp[i1].name,sp[i1].weight,sp[i1].height);
}
