#include <stdio.h>
#include <stdlib.h>

long fib( int n ) 
{ 
  if(n<2) return(1L);  
   else return( fib(n-1) + fib(n-2) );
}

main(int argc, char * argv[])
{
  printf("%ld\n", fib(atoi(argv[1])));
}




