#include <stdio.h>
#include <stdlib.h>

struct elist1 {
    int cont;
    struct elist1 * next;
};

struct dlist1 {
    struct elist1 * head;
    struct elist1 * tail;
}

in_fifo(struct dlist1 * q, int c)
{
  struct elist1 * e = malloc(sizeof(struct elist1));
  e->cont=c;
  e->next=NULL;
  if( q->head == NULL ) 
  {
    q->head = e;
    q->tail = e;
  }
  else
  {
    (q->tail)->next = e;
    q->tail=e;
  }
}

int out_fifo(struct dlist1 * q)
{
  struct elist1 * e;
  int c;
  if( q->head == NULL ) 
  {
    e = NULL;
  }
  else
  {
    e = q->head;
    q->head = e->next;
    e->next = NULL;
    if(q->tail==e) q->tail=NULL;
  }
  if(e==NULL) c=0; else { c=e->cont; free(e); }
  return(c);
}

in_lifo(struct dlist1 * q, int c)
{
  struct elist1 * e = malloc(sizeof(struct elist1));
  e->cont=c;
  e->next=NULL;
  if( q->head == NULL ) 
  {
    q->head = e;
    q->tail = e;
  }
  else
  {
    e->next = q->head;
    q->head=e;
  }
}

int out_lifo(struct dlist1 * q)
{
  struct elist1 * e;
  int c;
  if( q->head == NULL ) 
  {
    e = NULL;
  }
  else
  {
    e = q->head;
    q->head = e->next;
    e->next = NULL;
    if(q->tail==e) q->tail=NULL;
  }
  if(e==NULL) c=0; else { c=e->cont; free(e); }
  return(c);
}

main()
{
  struct dlist1 fifo1;
  struct dlist1 lifo1;
  
  fifo1.head=NULL;
  fifo1.tail=NULL;
  
  in_fifo(&fifo1,5);
  in_fifo(&fifo1,7);
  in_fifo(&fifo1,1);
  in_fifo(&fifo1,3);
  
  printf("%d\n",out_fifo(&fifo1));
  printf("%d\n",out_fifo(&fifo1));
  printf("%d\n",out_fifo(&fifo1));
  printf("%d\n",out_fifo(&fifo1));
  printf("%d\n",out_fifo(&fifo1));
  printf("%d\n",out_fifo(&fifo1));
  
  lifo1.head=NULL;
  lifo1.tail=NULL;
  
  in_lifo(&lifo1,5);
  in_lifo(&lifo1,7);
  in_lifo(&lifo1,1);
  in_lifo(&lifo1,3);
  
  printf("%d\n",out_lifo(&lifo1));
  printf("%d\n",out_lifo(&lifo1));
  printf("%d\n",out_lifo(&lifo1));
  printf("%d\n",out_lifo(&lifo1));
  printf("%d\n",out_lifo(&lifo1));
  printf("%d\n",out_lifo(&lifo1));
  
  getchar();
  
}
