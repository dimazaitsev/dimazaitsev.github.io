#include <stdio.h>
#include <stdlib.h>

struct elist1 {
    int cont;
    struct elist1 * next;
};

int llen(struct elist1 * a)
{
  if(a==NULL) return(0);
  else return(llen(a->next)+1);
}

void printlist1(struct elist1 * a)
{
  if(a!=NULL)
  {
    printf("%d ", a->cont);
    printlist1(a->next);
  }
}

void freelist1(struct elist1 * a)
{
  if(a!=NULL)
  {
    freelist1(a->next);
    free(a);
  }
}

struct elist1 * ldiv2(struct elist1 * a)
{
  int n = llen(a);
  int n1 = n/2;
  int n2 = n-n1;
  struct elist1 *x, *c=a;
  
  if(n==0)return(NULL);
  while(--n1) c=c->next;
  x=c->next;
  c->next=NULL;
  return(x);
}

struct elist1 * merge(struct elist1 * a1, struct elist1 * a2)
{
  struct elist1 *x1=a1, *x2=a2, *h=NULL, *c=NULL;
  int cond;
  
  while(x1!=NULL || x2!=NULL)
  {
    if(x2==NULL) cond = 1;
    else if(x1==NULL) cond = 0;
    else cond=(x1->cont < x2->cont);
    if( cond )
    {
      if(h==NULL)h=x1;
      if(c!=NULL) c->next=x1;
      c=x1;
      x1=x1->next;
    }
    else
    {
      if(h==NULL)h=x2;
      if(c!=NULL) c->next=x2;
      c=x2;
      x2=x2->next;
    }
  }
  if(c!=NULL) c->next=NULL;
  return(h);
}

struct elist1 * mergesort(struct elist1 * a)
{
  struct elist1 * a2;
  
  if(llen(a)<2) return(a);
  else
  {
    a2=ldiv2(a);
    return( merge(mergesort(a),mergesort(a2)) );
  }
}

main()
{
  struct elist1 *a=NULL, *e, *c=NULL;
  int x;
  
  while(!feof(stdin))
  {
    scanf("%d",&x);
    if(feof(stdin)) break;
    e=malloc(sizeof(struct elist1));
    e->cont=x;
    if(a==NULL) a=e;
    if(c!=NULL) c->next=e;
    c=e;
  }
  if(c!=NULL)c->next=NULL;
  
  printf("input:  ");
  printlist1(a);
  printf("\n");
  
  c=mergesort(a);
  printf("output: ");
  printlist1(c);
  printf("\n");
  
  freelist1(c);
  
}
