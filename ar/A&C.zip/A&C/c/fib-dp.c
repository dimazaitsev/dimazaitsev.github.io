#include <stdio.h>
#include <stdlib.h>

long ft[1000];
int ft_last;

long fib( int n ) 
{ 
  int i;
  if( n > ft_last ) 
  {
     for(i=ft_last+1;i<=n;i++)
       ft[i]=ft[i-2]+ft[i-1];
     ft_last = n;  
  }
  return(ft[n]);
}

main()
{
  int n;
  ft[0]=1L;
  ft[1]=1L;
  ft_last = 1;
  while(n!=0)
  {
    scanf("%d",&n);
    if(n==0)break;
    printf("f(%d)=%d\n",n,fib(n));
  }
}




