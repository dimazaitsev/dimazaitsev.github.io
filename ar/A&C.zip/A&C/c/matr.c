#include <stdio.h>
#include <stdlib.h>

#define MATRIX_SIZE(d1,d2,t) ((d1)*(d2)*(sizeof(t)))

#define MOFF(i,j,d1,d2) ((d2)*(i)+(j))
#define MELT(x,i,j,d1,d2) (*((x)+MOFF(i,j,d1,d2)))

main(int argc, char *argv[])
{
  int n,m,i,j;
  int *a;
  
  n=atoi(argv[1]);
  m=atoi(argv[2]);
  
  a=malloc( MATRIX_SIZE(n,m,int) );
  
  for(i=0; i<n; i++)
    for(j=0; j<m; j++)
      MELT(a,i,j,n,m)=rand()%100;

  printf("%d %d\n",n,m);
  for(i=0; i<n; i++)
  {
    for(j=0; j<m; j++)
      printf("%3d",MELT(a,i,j,n,m));  
    printf("\n");
  }
  
  free(a);
  
}
