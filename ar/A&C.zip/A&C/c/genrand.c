#include <stdio.h>
#include <stdlib.h>

main(int argc, char *argv[])
{
  int n,r,s,i;
  int *a;
  
  n=atoi(argv[1]);
  a=malloc(sizeof(int));
  for(i=0;i<n;i++)a[i]=0;
  
  while(1)
  {
    getchar();
    while(a[(r=rand()%n)]==1) ;
    a[r]=1;
    printf("%d\n",r+1);
  }
  free(a);
}
