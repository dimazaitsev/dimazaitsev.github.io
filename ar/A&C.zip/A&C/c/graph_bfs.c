#include <stdio.h>
#include <stdlib.h>

#define N 100

void m_const( int x[N][N], int n, int c )
{
  int i,j;
  for(i=0;i<n;i++)
    for(j=0;j<n;j++)
      x[i][j]=c;
}

void m_print( int x[N][N], int n )
{
  int i,j;
  printf("\n");
  for(i=0;i<n;i++)
  {
    for(j=0;j<n;j++)
      printf("%2d", x[i][j]);
    printf("\n");
  }
}

void a_const( int x[N], int n, int c )
{
  int i;
  for(i=0;i<n;i++)
      x[i]=c;
}

void a_copy( int x[N], int y[N], int n )
{
  int i;
  for(i=0;i<n;i++)
      y[i]=x[i];
}

main(int argc, char *argv[])
{
  int a[N][N];
  int b[N][N];
  int vv[N];
  int nv[N];
  int nv1[N];
  int n, l, i, j, k, v, v1, v2, go;
  
  scanf("%d",&n);
  if(n>N) return(2);
  scanf("%d",&l);
  printf("n=%d l=%d\n",n,l);
  
  m_const(a, n, 0);
  
  for(k=0;k<l;k++)
  {
    scanf("%d %d",&i, &j);
    printf("i=%d j=%d\n",i,j);
    a[i][j] = 1;
    a[j][i] = 1; // comment for directed
  }
  
  printf("a:\n");
  m_print(a, n);
  
  m_const(b, n, 0);
  a_const(nv, n, 0);
  a_const(vv, n, 0);
  v=atoi(argv[1]);  // first vertex
  vv[v]=1;          // visited vertices
  nv[v]=1;          // new vertices
  go=1;
  while(go)
  { 
    a_const(nv1, n, 0); // new new vertices
    go=0;
    for(v1=0;v1<n;v1++) // first vertex
    {
      if(nv[v1]==1) // it is new
      {
        for(v2=0;v2<n;v2++) // second vertex
        {
          if(a[v1][v2] && ! vv[v2] ) // there is an edge leading to a new vertex
          {
            vv[v2]=1;
            nv1[v2]=1;
            b[v1][v2]=1;
            b[v2][v1]=1; // comment for directed
            go=1;
          }
        }
      }
    }
    a_copy(nv1, nv, n);
  }
  
  printf("b:\n");
  m_print(b, n);
  
}
