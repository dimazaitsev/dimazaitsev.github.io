// Path of maximal length in a triangle of natural numbers
// Greedy approach
// Call: n3a < in_file
// Input file format: n <CR> <number> <CR> ...
// n - number of levels
// daze@acm.org
//
//     3
//    6 7
//   3 4 5
//  6 9 3 1
// 2 9 1 4 3
//
// 3+7+4+9+9=32

#include <stdio.h>

#define max(a,b) ((a>b)?a:b)

#define MI 1000
int a[MI][MI];

int main()
{
  int n,i,j,ip,x;
  long int ms, bms;
  
  // input triangle 
  scanf("%d",&n);
  if(n>MI) return(2);
  
  i=0;j=0;
  while(i<n)
  {
    scanf("%d",&x);
    a[i][j++] = x;
    if(j>i){i++;j=0;}
  }

  // print triangle 
  printf("input a: \n");
  i=0;j=0;
  while(i<n)
  {
    printf("%2d ",a[i][j++]);
    if(j>i){i++;j=0;printf("\n");}
  }
  
  // go greedy and print path
  ip=0;
  bms=a[0][0];
  printf("\ngreedy path: ");
  printf("%d ",ip);
  for(i=1; i<n; i++)
  {
    if(a[i][ip] >= a[i][ip+1]) ip=ip; else ip=ip+1;
    bms+=a[i][ip];
    printf("%d ",ip);    
  }

  // print the sum
  printf("\n");
  printf("\ngreedy sum %ld\n", bms);
  
}
