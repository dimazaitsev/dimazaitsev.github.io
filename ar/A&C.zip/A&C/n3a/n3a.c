// Path of maximal length in a triangle of natural numbers
// Dynamic programming approach
// Call: n3a < in_file
// Input file format: n <CR> <number> <CR> ...
// n - number of levels
// daze@acm.org
//
//     3
//    6 7
//   3 4 5
//  6 9 3 1
// 2 9 1 4 3
//
// 3+7+4+9+9=32

#include <stdio.h>

#define max(a,b) ((a>b)?a:b)

#define MI 1000
int a[MI][MI];
long int b[MI][MI];
int p[MI];

int main()
{
  int n,i,j, jm, x;
  long int ms, pr;
  
  // input triangle
  scanf("%d",&n);
  if(n>MI) return(2);
  
  i=0;j=0;
  while(i<n)
  {
    scanf("%d",&x);
    a[i][j++] = x;
    if(j>i){i++;j=0;}
  }
  
  // print triangle
  printf("input a: \n");
  i=0;j=0;
  while(i<n)
  {
    printf("%2d ",a[i][j++]);
    if(j>i){i++;j=0;printf("\n");}
  }
  
  // calculate matrix b of best sums
  b[0][0]=a[0][0];
  i=1;j=0;
  while(i<n)
  {
    if(j==0) b[i][j]=a[i][j]+b[i-1][j];
      else if(j==i) b[i][j]=a[i][j]+b[i-1][j-1];
	else b[i][j]=max((a[i][j]+b[i-1][j-1]),(a[i][j]+b[i-1][j]));
    
    if(++j>i){i++;j=0;}
  }
  
  // print matrix b
  printf("sums b:\n");
  i=0;j=0;
  while(i<n)
  {
    printf("%ld ",b[i][j++]);
    if(j>i){i++;j=0;printf("\n");}
  }
  
  // restore the best path from bottom to top
  ms=b[n-1][0];jm=0;
  for(j=1;j<n;j++) {if(b[n-1][j]>ms) {ms=b[n-1][j];jm=j;}}
  
  printf("last max %ld index %d\n",ms,jm);
  
  p[n-1]=jm;
  for(i=n-1;i>=1;i--)
  {
    if(p[i]==0) p[i-1]=0;
      else if(p[i]==i) p[i-1]=i-1;
	else
	{
	  pr=b[i][p[i]];
	  if(pr==a[i][p[i]]+b[i-1][p[i]-1]) p[i-1]=p[i]-1; else p[i-1]=p[i];
	}
  }
  
  // print the best sum and path
  printf("max path: ");
  
  for(i=0;i<n;i++)
    printf("%d ",p[i]);
  printf("\n");
  
}
