// Path of maximal length in a triangle of natural numbers
// Exhaustive search approach
// Call: n3a < in_file
// Input file format: n <CR> <number> <CR> ...
// n - number of levels
// daze@acm.org
//
//     3
//    6 7
//   3 4 5
//  6 9 3 1
// 2 9 1 4 3
//
// 3+7+4+9+9=32

#include <stdio.h>

#define max(a,b) ((a>b)?a:b)

#define MI 1000
int a[MI][MI];
int p[MI];
int bp[MI];

int main()
{
  int n,i,j, jm, x, go, k;
  long int ms, bms;
  
  // input triangle
  scanf("%d",&n);
  if(n>MI) return(2);
  
  i=0;j=0;
  while(i<n)
  {
    scanf("%d",&x);
    a[i][j++] = x;
    if(j>i){i++;j=0;}
  }
  
  // print triangle
  printf("input a: \n");
  i=0;j=0;
  while(i<n)
  {
    printf("%2d ",a[i][j++]);
    if(j>i){i++;j=0;printf("\n");}
  }
  
  // first path
  bms=0;
  for(i=0;i<n;i++){p[i]=0;bp[i]=0;bms+=a[i][0];}
  
  // exhaustive search - go to the next path
  go=1;
  while(go)
  {
    // next path
    go=0;
    for(i=n-1;i>0;i--)
    {
      if(p[i]<i && p[i]<=p[i-1])
      {
	      p[i]++; 
	      for(k=i+1;k<n;k++)p[k]=p[k-1];
	      go=1;
	      break;
      }
    }
        
    if(!go) break;
    
    // calculate sum
    ms=0;
    for(i=0;i<n;i++){ms+=a[i][p[i]];}

    // copy the best
    if(ms>bms)
    {
      for(i=0;i<n;i++){bp[i]=p[i];}
      bms=ms;
    }
  }
  
  // print the best sum and path
  printf("\nbest sum %ld\n", bms);
  printf("best path: ");
  for(i=0;i<n;i++){printf("%d ",bp[i]);}
  printf("\n");
}
