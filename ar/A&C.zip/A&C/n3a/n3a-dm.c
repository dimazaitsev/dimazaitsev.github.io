// Path of maximal length in a triangle of natural numbers
// Dynamic programming approach / dynamic allocation of arrays
// Call: n3a < in_file
// Input file format: n <CR> <number> <CR> ...
// n - number of levels
// daze@acm.org
//
//     3
//    6 7
//   3 4 5
//  6 9 3 1
// 2 9 1 4 3
//
// 3+7+4+9+9=32

#include <stdio.h>
#include <stdlib.h>

#define max(a,b) ((a>b)?a:b)

#define MATRIX_SIZE(d1,d2,t) ((d1)*(d2)*(sizeof(t)))
#define MOFF(i,j,d1,d2) ((d2)*(i)+(j))
#define MELT(x,i,j,d1,d2) (*((x)+MOFF(i,j,d1,d2)))

int main(int argc, char *argv[])
{
  int n,i,j, jm, x;
  long int ms, pr;
  int *a;
  long int *b;
  int *p;
  
  // input triangle
  scanf("%d",&n);
  a=malloc( MATRIX_SIZE(n,n,int) );
  b=malloc( MATRIX_SIZE(n,n,long int) );
  p=malloc( n*sizeof(int) );
  if( a==NULL || b==NULL || p==NULL) return(2);
  
  i=0;j=0;
  while(i<n)
  {
    scanf("%d",&x);
    MELT(a,i,j++,n,n) = x;
    if(j>i){i++;j=0;}
  }
  
  // print triangle
  if(argc>1)
  {
  printf("input a: \n");
  i=0;j=0;
  while(i<n)
  {
    printf("%2d ",MELT(a,i,j++,n,n));
    if(j>i){i++;j=0;printf("\n");}
  }
  }
  
  // calculate matrix b of best sums
  MELT(b,0,0,n,n) = MELT(a,0,0,n,n);
  i=1;j=0;
  while(i<n)
  {
    if(j==0) MELT(b,i,j,n,n)=MELT(a,i,j,n,n)+MELT(b,i-1,j,n,n);
      else if(j==i) MELT(b,i,j,n,n)=MELT(a,i,j,n,n)+MELT(b,i-1,j-1,n,n);
	else MELT(b,i,j,n,n)=max((MELT(a,i,j,n,n)+MELT(b,i-1,j-1,n,n)),(MELT(a,i,j,n,n)+MELT(b,i-1,j,n,n)));
    
    if(++j>i){i++;j=0;}
  }
  
  // print matrix b
  if(argc>1)
  {
  printf("sums b:\n");
  i=0;j=0;
  while(i<n)
  {
    printf("%ld ",MELT(b,i,j++,n,n));
    if(j>i){i++;j=0;printf("\n");}
  }
  }
  
  // restore the best path from bottom to top
  ms=MELT(b,n-1,0,n,n);jm=0;
  for(j=1;j<n;j++) {if(MELT(b,n-1,j,n,n)>ms) {ms=MELT(b,n-1,j,n,n);jm=j;}}
  
  printf("last max %ld index %d\n",ms,jm);
  
  p[n-1]=jm;
  for(i=n-1;i>=1;i--)
  {
    if(p[i]==0) p[i-1]=0;
      else if(p[i]==i) p[i-1]=i-1;
	else
	{
	  pr=MELT(b,i,p[i],n,n);
	  if(pr==MELT(a,i,p[i],n,n)+MELT(b,i-1,p[i]-1,n,n)) p[i-1]=p[i]-1; else p[i-1]=p[i];
	}
  }
  
  // print the best sum and path
  printf("max path: ");
  for(i=0;i<n;i++)
    printf("%d ",p[i]);
  printf("\n");
  
  free(a); free(b); free(p);
  
}
