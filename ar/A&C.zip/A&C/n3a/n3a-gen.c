// Path of maximal length in a triangle of natural numbers
// Generator of trianles
// Call: n3a n > out_file
// Output file format: n <CR> <number> <CR> ...
// n - number of levels
// daze@acm.org
//
//     3
//    6 7
//   3 4 5
//  6 9 3 1
// 2 9 1 4 3
//
// 3+7+4+9+9=32


#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int n,i,j,r;
  if(argc<2) return;
  n=atoi(argv[1]);
  printf("%d\n",n);
  i=0;j=0;
  while(i<n)
  {
    r=rand()%100;
    printf("%d\n",r);
    j++;
    if(j>i){i++;j=0;}
  }
  
}
