#include <stdio.h>
#include <unistd.h>
#include <semaphore.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define N 5

int main()
{
  int status, i;
  pid_t pid;
  char phi[5], phn[5];
  char sn[5];
  sem_t *s;

  printf("super_ph hello\n");
  for(i=1;i<=N;i++)
  {
      sprintf(sn,"f%d",i);
      s=sem_open(sn,O_CREAT,0644,1);
      if(s == SEM_FAILED)
      {
        printf("unable to create semaphore");
        return(2);
      }

  }

    sprintf(phn,"%d",N);
    for(i=1;i<=N;i++)
    {
      pid = fork ();
      if (pid == 0)
      {
        sprintf(phi,"%d",i);      
        execl("ph","ph", phi, phn,NULL);
        return(1);
      }
      else if (pid < 0)
      {
        //The fork failed.  Report failure.
        printf("*** fork error\n");
        return(2);
      }
    }

  printf("super_ph bue\n");
  return(0);

}
