#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>

main()
{
	int sock;
	uint16_t port=2233;
	struct sockaddr_in server, client;
	size_t size;
	char message1[1500];
	char message2[1500];
	int len;

	sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if( sock == -1 )
	{
		printf("Error create socket\n");
		exit(0);
	}
	server.sin_family = AF_INET;
	server.sin_port = htons (port);
	server.sin_addr.s_addr = htonl (INADDR_LOOPBACK);
	
	while(1)
	{
		printf("\ninput-message>");
		fgets(message1, 1500, stdin);
		len=strlen(message1)+1;
		size = sizeof(client);
		len = sendto ( sock, message1, len, 0, (struct sockaddr *)&server, size );
		if( len < 0 )
		{
			printf("Error send response\n");
			exit(0);
		}
		printf ("\nClient: sent message: %s\n", message1);
		len = recvfrom( sock, message2, 1500, 0, (struct sockaddr *)&server, &size );
		if( len < 0 )
		{
			printf("Error receive message\n");
			exit(0);
		}
		printf ("\nClient: got message: %s\n", message2);
		
	}
}
 
