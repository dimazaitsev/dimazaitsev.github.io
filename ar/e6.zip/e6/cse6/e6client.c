/* sample client application for e6 stack of protocols */
/* inputs and sends shell commands to server for remote execution */
/* Zaitsev D.A. (daze.ho.ua) & Kharsun M.A. (mikefromsky@gmail.com) */

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <netinet/ether.h>
#include "e6.h"

int main(int argc, char *argv[])
{
	int sock;
	uint16_t cport;
	uint16_t sport;
	struct e6_addr saddr;
	struct sockaddr_e6 server, client;
	socklen_t size;
	uint8_t *a = (uint8_t *)saddr.s_addr;
	struct ether_addr * ea;
	char message1[1500];
	char message2[1500];
	int len;
	
	if(argc<4) {printf("USAGE: e6client remote_e6_address remote_e6_port local_e6_port\n");exit(0);}
	cport=atoi(argv[3]);
	sport=atoi(argv[2]);
	memset(&saddr, 0, E6_ADDR_LEN );
	if( (ea=ether_aton(argv[1])) == NULL )
		printf("*** bad e6 address\n");
	else
		memcpy(&saddr, ea->ether_addr_octet, E6_ADDR_LEN );
	printf("--- e6 client from e6 port %d to e6 sever %02x:%02x:%02x:%02x:%02x:%02x (%d) ---\n",
		cport, a[0],a[1],a[2],a[3],a[4],a[5], sport);
	sock = socket(PF_E6, SOCK_DGRAM, IPPROTO_UDP);
	if( sock == -1 )
	{
		printf("Error create socket\n");
		exit(0);
	}
	client.se6_family = AF_E6;
	client.se6_port = htons (cport);
	client.se6_addr = E6ADDR_ANY;
	size = sizeof(client);
	if (bind (sock, (struct sockaddr *) &client, size) < 0)
	{
    		printf("Error bind socket\n");
    		exit (0);
	}

	while(1)
	{
		server.se6_family = AF_E6;
		server.se6_port = htons (sport);
		server.se6_addr = saddr;
		printf("\ninput-command>");
		fgets(message1, 1500, stdin);
		len=strlen(message1)+1;
		size = sizeof(client);
		len = sendto ( sock, message1, len, 0, (struct sockaddr *)&server, size );
		if( len < 0 )
		{
			printf("Error send response\n");
			exit(0);
		}
		printf ("\ne6 client: sent message: \n%s\n", message1);
		len = recvfrom( sock, message2, 1500, 0, (struct sockaddr *)&server, &size );
		if( len < 0 )
		{
			printf("Error receive message\n");
			exit(0);
		}
		printf ("\ne6 client: got response: \n%s\n", message2);
		
	}
}
 
/* end of e6client.c */
