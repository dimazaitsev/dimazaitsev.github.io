/* header file of e6 stack of protocols */
/* Zaitsev D.A. (daze.ho.ua) & Kharsun M.A. (mikefromsky@gmail.com) */

#ifndef	_NETE6_E6_H
#define	_NETE6_E6_H	1

#include <features.h>
#include <stdint.h>
#include <sys/socket.h>
#include <bits/types.h>


__BEGIN_DECLS

/* have to be added into socket.h */
#define	PF_E6		33
#define	AF_E6		PF_E6
#define E6_ADDR_LEN	6

/* Standard well-defined IP protocols.  */
enum
  {
    E6PROTO_TCP = 6,	   /* Transmission Control Protocol.  */
#define E6PROTO_TCP		E6PROTO_TCP
    E6PROTO_UDP = 17,	   /* User Datagram Protocol.  */
#define E6PROTO_UDP		E6PROTO_UDP
  };


/* Type to represent a port.  */
typedef uint16_t e6_port_t;

/* Standard well-known ports.  */
enum
  {
    E6PORT_ECHO = 7,		/* Echo service.  */
    E6PORT_DISCARD = 9,		/* Discard transmissions service.  */
    E6PORT_SYSTAT = 11,		/* System status service.  */
    E6PORT_DAYTIME = 13,	/* Time of day service.  */
    E6PORT_NETSTAT = 15,	/* Network status service.  */
    E6PORT_FTP = 21,		/* File Transfer Protocol.  */
    E6PORT_TELNET = 23,		/* Telnet protocol.  */
    E6PORT_SMTP = 25,		/* Simple Mail Transfer Protocol.  */
    E6PORT_TIMESERVER = 37,	/* Timeserver service.  */
    E6PORT_NAMESERVER = 42,	/* Domain Name Service.  */
    E6PORT_WHOIS = 43,		/* Internet Whois service.  */
    E6PORT_MTP = 57,

    E6PORT_TFTP = 69,		/* Trivial File Transfer Protocol.  */
    E6PORT_RJE = 77,
    E6PORT_FINGER = 79,		/* Finger service.  */
    E6PORT_TTYLINK = 87,
    E6PORT_SUPDUP = 95,		/* SUPDUP protocol.  */


    E6PORT_EXECSERVER = 512,	/* execd service.  */
    E6PORT_LOGINSERVER = 513,	/* rlogind service.  */
    E6PORT_CMDSERVER = 514,
    E6PORT_EFSSERVER = 520,

    /* UDP ports.  */
    E6PORT_BIFFUDP = 512,
    E6PORT_WHOSERVER = 513,
    E6PORT_ROUTESERVER = 520,

    /* Ports less than this value are reserved for privileged processes.  */
    E6PORT_RESERVED = 1024,

    /* Ports greater this value are reserved for (non-privileged) servers.  */
    E6PORT_USERRESERVED = 5000
  };


/* Internet address.  */
typedef uint8_t e6_addr_t[E6_ADDR_LEN];
struct e6_addr
  {
    e6_addr_t s_addr;
  };


/* Definitions of the bits in an Internet address integer.

   On subnets, host and network parts are found according to
   the subnet mask, not these masks.  */

/* Address to accept any incoming messages.  */
#define	E6ADDR_ANY		((struct e6_addr) {.s_addr={0x00,0x00,0x00,0x00,0x00,0x00}})
/* Address to send to all hosts.  */
#define	E6ADDR_BROADCAST	((struct e6_addr) {.s_addr={0x3f,0xff,0xff,0xff,0xff,0xff}})
/* Address indicating an error return.  */
#define	E6ADDR_NONE		((struct e6_addr) {.s_addr={0x3f,0xff,0xff,0xff,0xff,0xff}})

/* Network number for local host loopback.  */
#define	E6_LOOPBACKNET		0x00007f
/* Address to loopback in software to local host.  */
#ifndef E6ADDR_LOOPBACK
# define E6ADDR_LOOPBACK	((struct e6_addr) {.s_addr={0x00,0x00,0x7f,0x00,0x00,0x01}}) /* e6 0.0.127.0.0.1.  */
#endif

/* Get the definition of the macro to define the common sockaddr members.  */
#include <bits/socket.h>


/* Structure describing an Internet socket address.  */
struct sockaddr_e6
  {
    __SOCKADDR_COMMON (se6_);
    e6_port_t se6_port;			/* Port number.  */
    struct e6_addr se6_addr;		/* Internet address.  */

    /* Pad to size of `struct sockaddr'.  */
    unsigned char se6_zero[sizeof (struct sockaddr) -
			   __SOCKADDR_COMMON_SIZE -
			   sizeof (e6_port_t) -
			   sizeof (struct e6_addr)];
  };

__END_DECLS

#endif	/* e6.h */
