/* samle server application for e6 stack of protocols */
/* executes remote commands of shell */
/* Zaitsev D.A. (daze.ho.ua) & Kharsun M.A. (mikefromsky@gmail.com) */

#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/ether.h>
#include "e6.h"

int main(int argc, char *argv[])
{
	int sock;
	uint16_t port;
	struct sockaddr_e6 server, client;
	socklen_t size;
	uint8_t *a = (uint8_t *)client.se6_addr.s_addr;
	char message[1500];
	char buf[1500];
	int len;
	FILE *f;

	if(argc<2) {printf("USAGE: e6server local_e6_port\n");exit(0);}
	port=atoi(argv[1]);	
	printf("--- e6 server is listening on e6 port %d ---\n", (int) port);
	sock = socket(PF_E6, SOCK_DGRAM, IPPROTO_UDP);
	if( sock == -1 )
	{
		printf("Error create socket\n");
		exit(0);
	}
	server.se6_family = AF_E6;
	server.se6_port = htons (port);
	server.se6_addr = E6ADDR_ANY;

	if( bind( sock, (struct sockaddr*) &server, sizeof(server)) == -1 )
	{
		printf("Error bind socket\n");
		exit(0);
	}
	while(1)
	{
		size = sizeof(client);
		len = recvfrom( sock, message, 1500, 0, (struct sockaddr *)&client, &size );
		if( len < 0 )
		{
			printf("Error receive message\n");
			exit(0);
		}
		printf ("e6 server: from %02x:%02x:%02x:%02x:%02x:%02x (%d) got command: \n%s\n", 
			a[0],a[1],a[2],a[3],a[4],a[5], ntohs(client.se6_port), message);
		message[strlen(message)-1]='\0';
		strcat( message, " > res" );
		printf ("e6 server: execute command: \n%s\n", message);
		system( message );
		f=fopen("res","r");
		message[0]='\0';
		while(!feof(f))
		{
			fgets(buf, 1500, f);
			if( strlen(message) + strlen( buf) > 1480 ) break;
			if((!feof(f))) strcat(message,buf);
		}
		len = strlen(message)+1;
		len = sendto ( sock, message, len, 0, (struct sockaddr *)&client, size );
		if( len < 0 )
		{
			printf("Error send response\n");
			exit(0);
		}
		else printf ("e6 server: sent response: \n%s\n", message);
	}
}

/* end of e6client1.c */
