/* e6 protocols */

#include <linux/module.h>
#include <linux/kernel.h>
#include <asm/uaccess.h>
#include <linux/skbuff.h>
#include <linux/netdevice.h>
#include <linux/rtnetlink.h>
#include <linux/moduleparam.h>

#include <linux/types.h>
#include <linux/mm.h>
#include <linux/capability.h>
#include <linux/fcntl.h>
#include <linux/socket.h>
#include <linux/in.h>
#include <linux/inet.h>
#include <linux/if_packet.h>
#include <linux/kmod.h>
#include <net/ip.h>
#include <net/protocol.h>
#include <net/sock.h>
#include <linux/errno.h>
#include <linux/timer.h>
#include <asm/system.h>
#include <asm/ioctls.h>
#include <asm/page.h>
#include <asm/cacheflush.h>
#include <asm/io.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/poll.h>
#include <linux/init.h>

#define	PF_E6		33
#define	AF_E6		PF_E6
#define E6ADDRLEN	6

#define E6PORTSTART	4000
#define E6PORTSTEP	7
#define E6PORTMAX	0xffff

static char *e6_devname = "eth0";
static struct net_device *e6_dev;
static char *lo_devname = "lo";
static struct net_device *lo_dev;
static char *e6_devaddr = NULL;
#define ETH_P_E6	0xe600

module_param(e6_devname, charp, 0000);
MODULE_PARM_DESC(e6_devname, "The name of e6 device");
module_param(e6_devaddr, charp, 0000);
MODULE_PARM_DESC(e6_devaddr, "The address of e6 device");

static struct hlist_head e6_sklist;
static DEFINE_RWLOCK(e6_lock);

typedef __u16	e6_port_t;
typedef __u8	e6_addr_t[E6ADDRLEN];
struct e6_addr
{
	e6_addr_t s_addr;
};
struct e6_addr e6_myaddr;
static struct e6_addr zero_e6_addr = {.s_addr={0x00,0x00,0x00,0x00,0x00,0x00}};
static struct e6_addr lo_e6_addr = {.s_addr={0x00,0x00,0x7f,0x00,0x00,0x01}}; /* e6 0.0.127.0.0.1.  */
static e6_port_t e6_port_next = E6PORTSTART;
struct sockaddr_e6
{
	sa_family_t	se6_family;	/* Address family	*/
	e6_port_t	se6_port;	/* e6 port number.  */
	struct e6_addr	se6_addr;	/* e6 address.  */

    /* Pad to size of `struct sockaddr'.  */
    unsigned char __pad[sizeof (struct sockaddr) -
			   sizeof(short int) -
			   sizeof (e6_port_t) -
			   sizeof (struct e6_addr)];
};

struct e6_hdr {
	struct e6_addr		de6a;
	struct e6_addr		se6a;
	__be16			type;
	e6_port_t		de6p;
	e6_port_t		se6p;
};
#define E6_TRANSPORT_HEADER_OFFSET (sizeof(struct e6_hdr)-2*sizeof(e6_port_t))

struct e6_sock {
	struct sock sk;

	struct e6_addr		saddr;
	e6_port_t		sport;
	struct e6_addr		daddr;
	e6_port_t		dport;
	__u16			cmsg_flags;
};

struct e6_cb
{
	struct sockaddr_e6 se6;
};

static inline struct e6_sock *e6_sk(struct sock *sk)
{
	return (struct e6_sock *)sk;
}

static struct proto e6_proto = {
	.name	  = "E6",
	.owner	  = THIS_MODULE,
	.obj_size = sizeof(struct e6_sock),
};


static void e6_remove_socket(struct hlist_head *list, struct sock *sk)
{
	write_lock_bh(&e6_lock);
	sk_del_node_init(sk);
	write_unlock_bh(&e6_lock);
}

static void e6_insert_socket(struct hlist_head *list, struct sock *sk)
{
	write_lock_bh(&e6_lock);
	sk_add_node(sk, list);
	write_unlock_bh(&e6_lock);
}

const struct proto_ops e6_dgram_ops;

static int e6_create(struct net *net, struct socket *sock, int protocol)
{
	struct sock *sk;
	struct e6_sock *e6;
	int err;

	if (net != &init_net)
		return -EAFNOSUPPORT;
	
	err = -ESOCKTNOSUPPORT;
	if( sock->type != SOCK_DGRAM ) goto out;

	sock->state = SS_UNCONNECTED;

	err = -ENOBUFS;
	sk = sk_alloc(net, PF_E6, GFP_KERNEL, &e6_proto);
	if (sk == NULL)
		goto out;

	e6 = e6_sk(sk);

	sock->ops = &e6_dgram_ops;
	sock_init_data(sock, sk);

	sk->sk_no_check    = 1;
	sk->sk_family	   = PF_E6;
	sk->sk_protocol	   = protocol;

	e6_insert_socket(&e6_sklist, sk);
	err=0;

out: 	return(err);

}


static int e6_release(struct socket *sock)
{
	struct sock *sk;

	sk = sock->sk;
	if (!sk)
		goto out;

	e6_remove_socket(&e6_sklist, sk);

	/*
	 *	Now the socket is dead. No more input will appear.
	 */

	sk->sk_state_change(sk);	/* It is useless. Just for sanity. */

	sock->sk = NULL;
	sk->sk_socket = NULL;
	sock_set_flag(sk, SOCK_DEAD);

	skb_queue_purge(&sk->sk_receive_queue);

	sk_free(sk);

out:
	return 0;
}


static struct sock *e6_find_port(e6_port_t port)
{
	struct sock *sk;
	struct hlist_node *node;

	sk_for_each(sk, node, &e6_sklist) {
		struct e6_sock *opt = e6_sk(sk);
		if ( opt->sport == port )
			goto found;
	}
	sk = NULL;
found:
	return sk;
}


static e6_port_t e6_bind_port(void)
{
	e6_port_t p = e6_port_next;
	__u32 np;
	
	np = ((__u32)e6_port_next + E6PORTSTEP) % ((__u32)E6PORTMAX+1);
	e6_port_next = (np<E6PORTSTART)? E6PORTSTART + np : np;

	return p;
}

static int e6_bind(struct socket *sock, struct sockaddr *uaddr, int addr_len)
{
	struct sockaddr_e6 *addr = (struct sockaddr_e6 *)uaddr;
	struct sock *sk = sock->sk;
	struct e6_sock *e6 = e6_sk(sk);
	e6_port_t p;
	int err;

	err = -EINVAL;
	if (addr_len < sizeof(struct sockaddr_e6))
		goto out;
	
	if( addr->se6_port == 0 )
	{
		p = e6_bind_port();
		/* mutual prime give unique but all the ports can be exhausted */
		err = -EAGAIN;
		if (e6_find_port( htons(p) ) != NULL) goto out;
		e6->sport = htons(p);
	} else 
	{
		err = -EADDRNOTAVAIL;
		if( e6_find_port( addr->se6_port ) != NULL ) goto out;
		e6->sport = addr->se6_port;
	}

	e6->saddr = addr->se6_addr;

	e6->daddr = zero_e6_addr;
	e6->dport = 0;
	sk_dst_reset(sk);
	err = 0;

out:
	return err;

}


int e6_connect(struct socket *sock, struct sockaddr * uaddr, int addr_len, int flags)
{
	struct sockaddr_e6 *e6addr = (struct sockaddr_e6 *)uaddr;
	struct sock *sk = sock->sk;
	struct e6_sock *e6 = e6_sk(sk);

	if (addr_len < sizeof(*e6addr))
		return -EINVAL;

	if (e6addr->se6_family != AF_E6)
		return -EAFNOSUPPORT;

	sk_dst_reset(sk);

	e6->daddr = e6addr->se6_addr;
	e6->dport = e6addr->se6_port;
	sock->state = TCP_ESTABLISHED;

	return(0);
}


static int e6_sendmsg(struct kiocb *iocb, struct socket *sock, struct msghdr *msg, size_t len)
{
	struct sock *sk = sock->sk;
	struct sockaddr_e6 *saddr=(struct sockaddr_e6 *)msg->msg_name;
	struct sk_buff *skb;
	struct net_device *dev = e6_dev;
	int err;
	struct e6_sock *e6 = e6_sk(sk);
	struct e6_hdr *hdr;
	struct e6_addr addr, daddr;
	e6_port_t port, dport;

	addr	 = e6->saddr;
	if(memcmp(&addr,&zero_e6_addr,E6ADDRLEN)==0) addr = e6_myaddr;
	port	 = e6->sport;
	if (saddr == NULL) {
		daddr	 = e6->daddr;
		dport	 = e6->dport;
	} else {
		if (msg->msg_namelen < sizeof(struct sockaddr_e6)) {
			return -EINVAL;
		}
		daddr	= saddr->se6_addr;
		dport	= saddr->se6_port;
	}
	if((memcmp(&daddr, &e6_myaddr, E6ADDRLEN) == 0) || (memcmp(&daddr, &lo_e6_addr, E6ADDRLEN) == 0) ) /* loopback */
		dev	= lo_dev;

	err = -ENETDOWN;
	if (!(dev->flags & IFF_UP))
		goto out_unlock;

	err = -EMSGSIZE;
	if (len > dev->mtu + sizeof(struct e6_hdr))
		goto out_unlock;

	err = -ENOBUFS;
	skb = sock_alloc_send_skb(sk, len + sizeof(struct e6_hdr),msg->msg_flags & MSG_DONTWAIT, &err);

	if (skb == NULL)
		goto out_unlock;

	 /* Copy data */
  	skb_reserve(skb, sizeof(struct e6_hdr));
  	err = memcpy_fromiovec(skb_put(skb,len), msg->msg_iov, len);
	if (err) goto out_free;

	/* Set headers */
	skb_push(skb, sizeof(struct e6_hdr));
	skb_reset_mac_header(skb);
	skb_reset_network_header(skb);
	skb_reset_transport_header(skb);
	skb->protocol = ETH_P_E6;
	skb_set_transport_header(skb,E6_TRANSPORT_HEADER_OFFSET);

 	hdr = (struct e6_hdr *)skb_mac_header(skb);
	hdr->de6a = daddr;
	hdr->se6a = addr;
	hdr->type = htons(ETH_P_E6);
	hdr->de6p = dport;
	hdr->se6p = port;

 /*	if (dev->hard_header) {
		int res;
		err = -EINVAL;
		res = dev->hard_header(skb, dev, htons(ETH_P_E6), &addr, NULL, len);
		if (res < 0)
			goto out_free;
	}*/

	skb->dev = dev;
	skb->priority = sk->sk_priority;

	/* transmitt */
	dev_queue_xmit(skb);
	dev_put(dev);
	return(len);

out_free:
	kfree_skb(skb);
out_unlock:
	if (dev)
		dev_put(dev);
	return err;
}


static struct sock *e6_find_socket(e6_port_t port, struct e6_addr addr)
{
	struct sock *sk;
	struct hlist_node *node;

	sk_for_each(sk, node, &e6_sklist) {
		struct e6_sock *opt = e6_sk(sk);
		if ((opt->sport == port || opt->sport == 0) &&
		    (memcmp(&(opt->saddr),&addr,sizeof(struct e6_addr)) == 0 || memcmp(&(opt->saddr),&zero_e6_addr,sizeof(struct e6_addr)) == 0))
			goto found;
	}
	sk = NULL;
found:
	return sk;
}


static int e6_rcv(struct sk_buff *skb, struct net_device *dev, struct packet_type *pt, struct net_device *orig_dev)
{
	struct e6_hdr *hdr;
	struct sock *sk;
	struct e6_cb *e6cb;

/*	if (skb->pkt_type == PACKET_OTHERHOST)
		goto drop;*/

	if ((skb = skb_share_check(skb, GFP_ATOMIC)) == NULL)
		return NET_RX_DROP;

/*	if (!pskb_may_pull(skb, sizeof(struct e6_hdr)))
		goto drop;*/

	hdr = (struct e6_hdr *)(skb->data-E6_TRANSPORT_HEADER_OFFSET);
	if((memcmp(hdr->de6a.s_addr, &e6_myaddr, E6ADDRLEN) != 0) && (memcmp(hdr->de6a.s_addr, &lo_e6_addr, E6ADDRLEN) != 0) )
		goto drop;
	
	sk = e6_find_socket(hdr->de6p, hdr->de6a);
	if (!sk)
		goto drop;

	e6cb=(struct e6_cb *)skb->cb;
	e6cb->se6.se6_family=AF_E6;
	e6cb->se6.se6_addr=hdr->se6a;
	e6cb->se6.se6_port=hdr->se6p;

	if (sock_queue_rcv_skb(sk, skb))
		goto drop;

	return 0;

drop:
	kfree_skb(skb);
	return NET_RX_DROP;
}


static int e6_recvmsg(struct kiocb *iocb, struct socket *sock, struct msghdr *msg, size_t len, int flags)
{
	struct sock *sk = sock->sk;
	struct sk_buff *skb;
	size_t copied;
	int err;

	msg->msg_namelen = sizeof(struct sockaddr_e6);

	skb=skb_recv_datagram(sk,flags,flags&MSG_DONTWAIT,&err);

	if(skb==NULL)
		goto out;

	copied = skb->len;
	if (copied > len)
	{
		copied=len;
		msg->msg_flags|=MSG_TRUNC;
	}

	/* We can't use skb_copy_datagram here */
	err = memcpy_toiovec(msg->msg_iov, skb->data+4, copied);
	if (err)
		goto out_free;
	sk->sk_stamp = skb->tstamp;

	if (msg->msg_name)
	{
		memcpy(msg->msg_name, skb->cb, msg->msg_namelen);
	}

	err = copied;

out_free:
	skb_free_datagram(sk, skb);
out:
	return err;
}


const struct proto_ops e6_dgram_ops = {
	.family		   = PF_E6,
	.owner		   = THIS_MODULE,
	.release	   = e6_release,
	.bind		   = e6_bind,
	.connect	   = e6_connect,
	.socketpair	   = sock_no_socketpair,
	.accept		   = sock_no_accept,
	.getname	   = sock_no_getname,
	.poll		   = datagram_poll,
	.ioctl		   = sock_no_ioctl,
	.listen		   = sock_no_listen,
	.shutdown	   = sock_no_shutdown,
	.setsockopt	   = sock_common_setsockopt,
	.getsockopt	   = sock_common_getsockopt,
	.sendmsg	   = e6_sendmsg,
	.recvmsg	   = e6_recvmsg,
	.mmap		   = sock_no_mmap,
	.sendpage	   = sock_no_sendpage,
};


static struct net_proto_family e6_family_ops = {
	.family = PF_E6,
	.create = e6_create,
	.owner	= THIS_MODULE,
};


static struct packet_type e6_packet_type = {
	.type	=	__constant_htons(ETH_P_E6),
	.func	=	e6_rcv,
};

__u8 e6_xdigit( char c ){__u8 x; if(c>='0'&&c<='9') x=c-'0'; else if(c>='a'&&c<='f') x=c-'a'+10; else if(c>='A'&&c<='F') x=c-'A'+10; else x=0; return x;}

static struct net_device *e6_init_dev(const char * e6devname, const char * e6devaddr, struct e6_addr * e6myaddr)
{
	int i, j, ok;
	int err=0;
	struct net_device *e6d;
	__u8 *a = e6myaddr->s_addr;

	/* find & set e6_dev */
	e6d = dev_get_by_name(&init_net,e6devname);
	if (!e6d) {
	   printk(KERN_ERR "*** e6 (ERR): init: %s doesn't exist ***\n", e6devname);
		goto out;
	}

	if( e6devaddr != NULL )
	{
		j=0; ok=1;
		for( i=0; i<E6ADDRLEN; i++ )
		{
			if( e6devaddr[j] == '\0' ) { ok=0; break; }
			a[i] = e6_xdigit(e6devaddr[j++]) * 0x10;
			if( e6devaddr[j] == '\0' ) { ok=0; break; }
			a[i] += e6_xdigit(e6devaddr[j++]);
		}
		if( ok )
		{
        		printk("<1>*** e6: init: get e6_devaddr=%02x:%02x:%02x:%02x:%02x:%02x, alen=%d ***\n", 
              			a[0],a[1],a[2],a[3],a[4],a[5], E6ADDRLEN );
			rtnl_lock();
			(e6d->netdev_ops)->ndo_stop( e6d );
			
			memcpy(e6d->dev_addr, a, e6d->addr_len );

			(e6d->netdev_ops)->ndo_open(e6d);
			rtnl_unlock();

			if (err)
				printk(KERN_ERR "*** e6 (ERR): init: failed to set e6 addr, err=%d ***\n", err );
		}			
	}

        if (!((e6d->netdev_ops)->ndo_poll_controller)) {
		printk(KERN_ERR "*** e6: init: %s doesn't support polling ***\n", e6devname );
	}

	if (!netif_running(e6d)) {
		printk(KERN_INFO "*** e6: init: device %s not up ***\n", e6devname );
		rtnl_lock();
		err = dev_open(e6d);
		rtnl_unlock();

		if (err) {
			printk(KERN_ERR "*** e6 (ERR): init: %s failed to open, err=%d ***\n", e6devname, err );
			return NULL;
		}
	}

	memcpy( a, e6d->dev_addr, e6d->addr_len );
        printk("<1>*** e6: init: myMAC=%02x:%02x:%02x:%02x:%02x:%02x, alen=%d ***\n", 
              a[0],a[1],a[2],a[3],a[4],a[5], e6d->addr_len );

out:
	return e6d;
}

static int __init e6_init(void)
{
	int rc = proto_register(&e6_proto, 0);

	if (rc != 0) goto out;

        printk("<1>*** e6: init: devname=%s ***\n", e6_devname);

	e6_dev = e6_init_dev(e6_devname, e6_devaddr, &e6_myaddr);
	if ( e6_dev == NULL ) { rc=-1; goto out; }

	lo_dev = dev_get_by_name(&init_net,lo_devname);
	if ( lo_dev == NULL ) { rc=-1; printk(KERN_ERR "*** e6 (ERR): init: %s doesn't exist ***\n", lo_devname); goto out; }

/*	e6_packet_type.dev = e6_dev;*/

	sock_register(&e6_family_ops);
	dev_add_pack(&e6_packet_type);

out:
	return rc;
}
module_init(e6_init);


static void __exit e6_exit(void)
{
	printk("<1>*** e6: exit: devname=%s ***\n", e6_devname);
	dev_remove_pack(&e6_packet_type);

	sock_unregister(PF_E6);
	proto_unregister(&e6_proto);
}
module_exit(e6_exit);

MODULE_AUTHOR("Dmitry Zaitsev <zsoftua@yahoo.com>");
MODULE_DESCRIPTION("E6 protocols implementation");
MODULE_LICENSE("GPL");
MODULE_ALIAS_NETPROTO(PF_E6); 
